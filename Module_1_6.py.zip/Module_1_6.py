my_dict = {'Alex': 2001, 'Max': 2002, 'Cat': 2018}
print('Dict:',my_dict)
print('Existing value:', my_dict['Cat'])
print('Not existing value:', my_dict.get('Dog'))
my_dict.update({'Mom': 1964, 'Bro': 1991})
a = my_dict.pop('Cat')
print('Deleted value:', a)
print('Modified dictionary:', my_dict)

#3
my_set = {1, 2, 'three', 4.0, 1, 2, 'three'}
print('Set:', my_set)
my_set.add(6)
my_set.add(3)
my_set.remove(1)
print('Modified set:', my_set)